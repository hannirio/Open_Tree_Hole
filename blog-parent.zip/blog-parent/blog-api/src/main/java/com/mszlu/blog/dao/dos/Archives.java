package com.mszlu.blog.dao.dos;

import lombok.Data;

@Data
public class Archives {
    private Integer year;
    private Integer month;
    private Long count;
}
