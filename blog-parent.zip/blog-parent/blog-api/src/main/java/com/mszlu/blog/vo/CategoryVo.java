package com.mszlu.blog.vo;

import lombok.Data;

import java.util.List;

@Data
public class CategoryVo {

    private String id;

    private String avatar;

    private String categoryName;

    private String description;
}